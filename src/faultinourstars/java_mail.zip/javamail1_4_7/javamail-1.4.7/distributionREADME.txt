DistributionREADME

DISTRIBUTION BY DEVELOPERS.  Subject to the terms and conditions of the
Software License Agreement and the obligations, restrictions, and
exceptions set forth below, You may reproduce and distribute the
portions of Software identified below ("each a Redistributable"),
provided that You comply with the following (note that You may be
entitled to reproduce and distribute other portions of the Software not
defined here as a Redistributable under certain other licenses as
described in the THIRDPARTYLICENSEREADME, if applicable):

(a) You distribute the Redistributable complete and unmodified and only
bundled as part of Your applets and applications ("Programs"),

(b) Your Programs add significant and primary functionality to the
Software

(c) You distribute Redistributable for the sole purpose of running Your
Programs,

(d) You do not distribute additional software intended to replace any
component(s) of the Redistributable,

(e) You do not remove or alter any proprietary legends or notices
contained in or on the Redistributable.

(f) You only distribute the Redistributable subject to a license
agreement that protects Oracle's interests consistent with the terms
contained in the Software License Agreement, and

(g) You agree to defend and indemnify Oracle and its licensors from and
against any damages, costs, liabilities, settlement amounts and/or
expenses  (including attorneys' fees) incurred in connection with any
claim, lawsuit or action by any third party that arises or results from
the use or distribution of any and all Programs and/or
Redistributable.

The following files are each a Redistributable:

mail.jar
lib/mailapi.jar
lib/imap.jar
lib/smtp.jar
lib/pop3.jar
lib/dsn.jar
